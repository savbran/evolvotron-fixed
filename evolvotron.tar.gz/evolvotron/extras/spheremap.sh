#!/bin/bash

# Disclaimer: I'm using povray version "3.5 Unix".  Which is probably quite old now.

povray spheremap.pov +KFI1 +KFF100 +H240 +W320 +Of.png
